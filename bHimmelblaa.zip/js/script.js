$('*[sub-hover]').hover(
  function () {
	var id = this.getAttribute("sub-hover");
	$('*[sub-menu]').hide();
	$('*[sub-menu='+ id +']').show();
  }
);
$('.sub').hover(function(){
}, function(){
	$('*[sub-menu]').hide();
	$('*[sub-menu=0]').show();
})
